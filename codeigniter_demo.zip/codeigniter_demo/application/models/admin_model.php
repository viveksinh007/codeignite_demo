<?php

class admin_model extends CI_Model
{

    public function is_admin($username, $password)
    {
        $q = $this->db->where(['username' => $username, 'password' => $password])
            ->get('users');

        if ($q->num_rows()) {
            return $q->row()->id;
        } else {
            return false;
        }
    }

    // public function get_articles($limit, $offset)
    // {
    //     $id = $this->session->userdata('user_id');

    //     $q = $this->db->select()
    //         ->from('articles')
    //         ->where(['user_id' => $id])
    //         ->limit($limit, $offset)
    //         ->get();
    //     return $q->result();
    // }

    public function get_article_num_rows()
    {
        $id = $this->session->userdata('user_id');

        $q = $this->db->select()
            ->from('articles')
            ->where(['user_id' => $id])
            ->get();
        return $q->num_rows();
    }

    //for get all records from database

    
    public function get_articles()
    {
    $id = $this->session->userdata('user_id');
    $q = $this->db->select('*')->from('articles')->where(['user_id' => $id])->get();
    return $q->result();
    }
     

    public function insert_article($article_data_array)
    {
        $this->db->set('article_title', $article_data_array['article_title']);
        $this->db->set('article_body', $article_data_array['article_body']);
        $this->db->set('user_id', $article_data_array['user_id']);
        return $this->db->insert('articles');
    }

    public function del_article($id)
    {
        return $this->db->delete('articles', ['id' => $id]);
    }

    public function get_edit_article_date($article_id)
    {
       $q =  $this->db->select(['id','article_title','article_body'])
                 ->where('id', $article_id)
                 ->get('articles');
                 return $q->row();
    }

    public function update_Article($article_id,Array $article){

        return $this->db->where('id', $article_id)
                 ->update('articles', $article);
    }
}
