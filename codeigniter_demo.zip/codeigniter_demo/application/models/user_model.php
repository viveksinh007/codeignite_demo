<?php

class user_model extends CI_Model
{
    public function new_user($username, $password)
    {
        $this->db->set('username', $username);
        $this->db->set('password', $password);
        return $this->db->insert('users');
    }
}
