<?php

class stud_model extends CI_Model
{

    public function __construct()
    {

        parent::__construct();

    }

    //for inserting data
    public function insert($data)
    {

        if ($this->db->insert("student", $data)) {

            return true;    
        }

    }

    //for Deleteing data
    public function delete($id)
    {

        if ($this->db->delete("student", "s_id =" . $s_id)) {

            return true;

        }

    }

    //for updateing data
    public function update($data, $s_id)
    {
        $this->db->set($data);
        $this->db->where("s_id", $s_id);
        $this->db->update("student", $data);

    }
}
