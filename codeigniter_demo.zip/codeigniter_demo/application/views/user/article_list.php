<?php include 'header.php'?>


<div class="container my-5">

    <h1>Articles</h1>

</div>

<?php include 'footer.php'?>