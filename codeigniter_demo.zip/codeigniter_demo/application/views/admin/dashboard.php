<?php include 'header.php'?>

<div class="container my-5">



    <div class="row md-6 my-4 ">
        <div class="col-md-3">
            <h1>Article List</h1>
        </div>

        <div class="col-md-6">
            <a href="add_article_btn" class="btn btn-lg btn-primary">Add Article</a>
        </div>
    </div>

    <div class="row">
        <?php if ($msg = $this->session->flashdata('msg')) {

        $color = $this->session->flashdata('msg_class');

    ?>
        <div class="alert <?= $color; ?>"> <?=$msg;?> </div>

        <?php }?>
    </div>

    <div class="row">

        <!-- <?= $this->pagination->create_links(); ?> -->

        <!--  <?php print_r($articles)?> -->

        <div class="table-responsive">
            <table id="example" class="table table-striped table-bordered">
        <thead>
               
                    <tr>
                        <th >Id</th>
                        <th >Article Title</th>
                        <th >Edit</th>
                        <th >Delete</th>
                    </tr> 
        </thead>
        <tbody>
                    <?php

if (count($articles)) {
    $i = 1;
    foreach ($articles as $article) {

        ?>
                    <tr>
                        <th><?=$i?></th>
                        <td><?=$article->article_title?></td>
                        <td>
                            <?=
                                form_open('admin/edit_btn'),
                                form_hidden('id',$article->id),
                                form_submit(['type' => 'submit', 'class' => 'btn btn-primary', 'name' => 'Edit', 'value' => 'Edit']),
                                form_close();
                            ?> 
                        </td>
                        <td>
                            <?=
                                form_open('admin/delete_article'),
                                form_hidden('id',$article->id),
                                form_submit(['type' => 'submit', 'class' => 'btn btn-danger', 'name' => 'Delete', 'value' => 'Delete']),
                                form_close();
                            ?>
                        </td>
                    </tr>
                    <?php
$i++;
    }
} else {
    ?>

                    There is no articles available

                    <?php
}
?>
             </tbody>   
            </table>

        </div>
    </div>

    <?php include 'footer.php'?>