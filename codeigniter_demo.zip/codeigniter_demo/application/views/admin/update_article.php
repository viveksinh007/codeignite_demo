<?php include 'header.php'?>

<div class="container my-5">


    <div class="container">

        <h1>Edit Article</h1>

        <?php if ($error = $this->session->flashdata('login_failed')) {?>

        <div class="alert alert-danger"> <?=$error;?> </div>

        <?php }?>

        <?php echo form_open('admin/update_article'); ?>
        <?php echo form_hidden('id',$article->id); ?>
        <div class="form-group my-4">
            <label for="exampleInputEmail1">Article Title :</label>
            <?php echo form_input(['class' => 'form-control', 'name' => 'article_title', 'placeholder' => 'Enter Atricle Title', 'value' => set_value('article_title',$article->article_title)]); ?>
            <?php echo form_error('article_title'); ?>
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1">Article Body :</label>
            <?php echo form_textarea(['class' => 'form-control', 'name' => 'article_body', 'placeholder' => 'Enter Article Body', 'value' => set_value('article_body',$article->article_body)]); ?>
            <?php echo form_error('article_body'); ?>
        </div>

        <?php echo form_submit(['type' => 'submit', 'class' => 'btn btn-primary', 'value' => 'Update']); ?>
        <?php echo form_reset(['type' => 'reset', 'class' => 'btn btn-primary', 'value' => 'Reset']); ?>

        <?php form_close();?>
    </div>
</div>

<?php include 'footer.php'?>