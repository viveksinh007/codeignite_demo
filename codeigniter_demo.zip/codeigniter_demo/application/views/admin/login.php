<?php include 'header.php'?>

<div class="container my-5">


    <div class="container">
        <div class="row">
            <div class="col-md">

            </div>
            <div class="col-md">
                <h1>Admin Login</h1>


                <?php if ($msg = $this->session->flashdata('msg')) {

                $color = $this->session->flashdata('msg_class');

                ?>
                
                <div class="alert <?=$color;?>"> <?=$msg;?> </div>

                <?php }?>


                <?php echo form_open('admin/login'); ?>
                <div class="form-group my-4">
                    <label for="exampleInputEmail1">User Name :</label>
                    <?php echo form_input(['class' => 'form-control', 'name' => 'uname', 'placeholder' => 'Enter User Name', 'value' => set_value('uname')]); ?>
                    <?php echo form_error('uname'); ?>
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Password :</label>
                    <?php echo form_password(['class' => 'form-control', 'name' => 'pass', 'placeholder' => 'Enter Password', 'value' => set_value('password')]); ?>
                    <?php echo form_error('pass'); ?>
                </div>

                <?php echo form_submit(['type' => 'submit', 'class' => 'btn btn-primary', 'name' => 'submit', 'value' => 'Log in']); ?>
                <?php echo form_reset(['type' => 'reset', 'class' => 'btn btn-primary', 'name' => 'reset', 'value' => 'Reset']); ?>

                <?php form_close();?>
            </div>

            <div class="col-md">

            </div>
        </div>
    </div>


</div>

<?php include 'footer.php'?>