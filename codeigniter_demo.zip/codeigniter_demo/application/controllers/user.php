<?php

class user extends CI_Controller
{
    public function index()
    {
        $this->load->view("user/article_list");
    }

    public function sign_up()
    {
        $this->load->view("user/user_sign_up");
    }

    public function create_new_user()
    {
        $this->form_validation->set_rules('uname', 'User_Name', 'required|alpha');
        $this->form_validation->set_rules('pass', 'Password', 'required|max_length[8]');
        $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');

        if ($this->form_validation->run()) {
        
            $uname = $this->input->post('uname');
            $pass = $this->input->post('pass');
            $this->load->model('user_model');
            if ($this->user_model->new_user($uname,$pass)) {

                $this->session->set_flashdata('user_added', ' Acount has been created successfully');
                $this->session->set_flashdata('user_added_class', 'alert-success');
                
            } else {

                $this->session->set_flashdata('user_added', ' Acount Creation Failed , Try again ! ');
                $this->session->set_flashdata('user_added_class', 'alert-danger');

            }
            $this->load->view("user/user_sign_up");
        }
        else {
            $this->load->view("user/user_sign_up");
        }
    }
}