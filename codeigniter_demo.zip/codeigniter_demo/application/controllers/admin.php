<?php
defined('BASEPATH') or exit('No direct script access allowed');
class admin extends CI_Controller
{

    public function login()
    {
        if ($this->session->userdata('user_id')) {
            return redirect('admin/welcome');
        } else {
            $this->form_validation->set_rules('uname', 'User_Name', 'required|alpha');
            $this->form_validation->set_rules('pass', 'Password', 'required|max_length[8]');
            $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
            if ($this->form_validation->run()) {
                $uname = $this->input->post('uname');
                $pass = $this->input->post('pass');
                $this->load->model('admin_model');
                $id = $this->admin_model->is_admin($uname, $pass);
                if ($id) {
                    $this->session->set_userdata('user_id', $id);
                    return redirect('admin/welcome');
                } else {
                    $this->session->set_flashdata('login_failed', 'Invalid Username/Password ');
                    return redirect('admin/login');
                }
            } else {
                $this->load->view("admin/login");
            }
        }
    }

    public function welcome()
    {
        $this->load->model('admin_model');

        // $config = [
        //     'base_url' => base_url('admin/welcome'),
        //     'per_page' => 3,
        //     'total_rows' => $this->admin_model->get_article_num_rows(),
        //     'full_tag_open' => '<div class="pagination">',
        //     'full_tag_close' => '</div>',
        //     'full_tag_open' => "<ul class='pagination'>",
        //     'full_tag_close' => "</ul>",
        //     'next_tag_open' => "<li>",
        //     'next_tag_close' => "</li>",
        //     'prev_tag_open' => "<li>",
        //     'prev_tag_close' => "</li>",
        //     'num_tag_open' => "<li>",
        //     'num_tag_close' => "<li>",
        //     'cur_tag_open' => "<a class='active'>",
        //     'cur_tag_close' => "</a>",

        // ];

        // $this->pagination->initialize($config);

        // $articles = $this->admin_model->get_articles($config['per_page'], $this->uri->segment(3));

        $articles = $this->admin_model->get_articles();
        $this->load->view("Admin/dashboard", ['articles' => $articles]);
    }

    public function logout_btn()
    {
        $this->session->unset_userdata('user_id');
        $this->load->view('admin/login');
    }

    public function add_article_btn()
    {
        $this->load->view('admin/add_articles');
    }

    public function add_article_data()
    {
        $this->form_validation->set_rules('article_title', 'Article Title', 'required|max_length[30]');
        $this->form_validation->set_rules('article_body', 'Atricle Body', 'required');
        $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
        if ($this->form_validation->run()) {
            $post = $this->input->post();
            // echo "<pre>";
            // echo print_r($post);
            $this->load->model('admin_model');

            if ($this->admin_model->insert_article($post)) {

                $this->session->set_flashdata('msg', 'Article Added successfully ');
                $this->session->set_flashdata('msg_class', 'alert-success');

            } else {

                $this->session->set_flashdata('msg', 'Article Added Failed ');
                $this->session->set_flashdata('msg_class', 'alert-danger');

            }
            return redirect('admin/welcome');
        } else {
            $this->load->view('admin/add_articles');
        }
    }

    public function delete_article()
    {
        $id = $this->input->post('id');
        $this->load->model('admin_model');
        if ($this->admin_model->del_article($id)) {

            $this->session->set_flashdata('msg', 'Article Delete successfully ');
            $this->session->set_flashdata('msg_class', 'alert-success');

        } else {

            $this->session->set_flashdata('msg', 'Article Delete Failed , Try Again !');
            $this->session->set_flashdata('msg_class', 'alert-danger');

        }
        return redirect('admin/welcome');
    }

    public function edit_btn()
    {
        $id = $this->input->post('id');
        $this->load->model('admin_model');
        $article_row_date = $this->admin_model->get_edit_article_date($id);
        $this->load->view('admin/update_article', ['article' => $article_row_date]);

    }

    public function update_article()
    {
        
        $post = $this->input->post();
        $aid = $post['id'];
        $this->form_validation->set_rules('article_title', 'Article Title', 'required|max_length[30]');
        $this->form_validation->set_rules('article_body', 'Atricle Body', 'required');
        $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
        if ($this->form_validation->run()) {
            $post = $this->input->post();
            
            $this->load->model('admin_model');

            if ($this->admin_model->update_article($aid,$post)) {

                $this->session->set_flashdata('msg', 'Article Edit successfully ');
                $this->session->set_flashdata('msg_class', 'alert-success');

            } else {

                $this->session->set_flashdata('msg', 'Article Edit Failed ');
                $this->session->set_flashdata('msg_class', 'alert-danger');

            }
            return redirect('admin/welcome');
        } else {
            $this->load->view('admin/edit_btn');
        }
    }

}